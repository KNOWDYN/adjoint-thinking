# Release Notes — v1.0.0

Release date: 2026-06-27

## Summary

Adjoint Thinking Environment Pack v1.0.0 is a browser-only, no-code configuration package for creating source-grounded AI thinking environments in ChatGPT Projects, Claude Projects, or Gemini Gems.

The release uses one README as the installer, five default package files for normal users, expanded prompt assets for advanced users, and audit files for source-method transparency.

## What is locked

- One README installer for all three platforms.
- Five default deployment files under `package/`.
- One compact router-first prompt system.
- One Unified Response Template that standardizes response order only.
- Ten expanded prompt assets: one meta-configuration asset and nine Adjoint Thinking co-thinking assets.
- Source-available non-commercial license.
- Bespoke SECURITY.md.
- Source manifest, release gate report, and local build checks.

## Known limitations

- The package cannot guarantee correctness of model outputs.
- The package cannot guarantee viral success.
- The package is not professional legal, medical, financial, engineering, clinical, regulatory, safety, or cybersecurity advice.
- Platform interfaces, file limits, plan names, and feature availability can change.
- Commercial use requires a separate KNOWDYN LTD license.
