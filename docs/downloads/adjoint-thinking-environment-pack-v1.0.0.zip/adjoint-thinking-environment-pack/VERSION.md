# Version

Package: Adjoint Thinking Environment Pack
Version: 1.0.0
Release status: Locked release
Release date: 2026-06-27
Copyright holder: KNOWDYN LTD
License: Adjoint Thinking Environment Pack Source-Available Non-Commercial License

## Release identity

This version is the first locked public release of the browser-only Adjoint Thinking environment configuration package for ChatGPT Projects, Claude Projects, and Gemini Gems.

## Release rule

Do not change files inside a v1.0.0 distribution without incrementing the version and updating the changelog.
