# Changelog

## 1.0.0 — 2026-06-27

Release locked as v1.0.0.

- Locked the release-grade browser-only environment pack.
- Confirmed one README as the step-by-step installer for ChatGPT Projects, Claude Projects, and Gemini Gems.
- Confirmed default deployment uses five package files under `package/`.
- Confirmed expanded prompt assets remain available under `expanded_prompts/`.
- Confirmed method, stress-test, reasoning-compatibility, and release-gate materials remain available under `audit/`.
- Confirmed source-available non-commercial license is included.
- Confirmed bespoke SECURITY.md is included.
- Confirmed chain-of-thought safety language and reasoning-not-verification rule are present.
- Confirmed commercial asset production requires a separate KNOWDYN LTD license.

## 1.0.0-rc1 — 2026-06-27

- Rebuilt package as release-grade browser-only environment pack.
- Added one README with step-by-step installation guidance for ChatGPT Projects, Claude Projects, and Gemini Gems.
- Added source-available non-commercial license draft.
- Added bespoke SECURITY.md for prompt-injection, sensitive-data, and AI-output risks.
- Added compact deployment files under `package/`.
- Preserved expanded prompt assets under `expanded_prompts/`.
- Preserved method and stress-test materials under `audit/`.
- Added reasoning-model compatibility rules.
- Added non-technical validation prompts.
